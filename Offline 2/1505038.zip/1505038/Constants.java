/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package n.puzzle.solver.using.a.star.search.algorithm;

/**
 *
 * @author Heisenberg
 */
public class Constants {
    public static int rowNum, colmNumber, N;
    public static heuristicName HeuristicType; 
}

enum heuristicName{
     Man, Ham, Conf; 
}